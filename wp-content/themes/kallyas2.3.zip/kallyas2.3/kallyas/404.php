<?php get_header(); 


?>




		</div><!-- end page_header -->
<div class="error404-page">

	<section id="content">
		<div class="container">
			
			<div id="mainbody">
				
				<div class="row">
					<div class="span12">
						
						<div class="error404-content">
							<h2><span>404</span></h2>
							<h3><?php echo __("The page cannot be found.",THEMENAME);?></h3>
						</div>
						
					</div>
				</div><!-- end row -->
				
			</div><!-- end mainbody -->
			
		</div><!-- end container -->
	</section><!-- end #content -->
</div>
<?php get_footer(); ?>